<!-- // CANVAS START -->
 <!DOCTYPE html>
 <html lang="en">
  <head>
    <title>SPCTR</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/x-icon" href="Site/contents/images/favicon/microchip.png">
    <!-- Some style configs -->
    <link rel="stylesheet" href="Site/contents/css/index/index.css" media="screen">
    <link rel="stylesheet" href="Site/contents/global/css/fonts.css">
  </head>

  <body class="root">
    <!-- Let's start with a basic navigation bar -->
    <div class="navbar">
      <ul class="nav-rt">
        <li class="active"><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Projects</a></li>
        <li><a href="#">Timeline</a></li>
        <!-- Right links -->
        <li id="right"><a href="#">Register</a></li>
        <li id="right"><a href="#">Login</a></li>
      </ul>
    </div>
  </body>
 </html>